create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  seller_type text default 'private',
  created_at timestamptz default now()
);
create table listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid references profiles(id) on delete cascade,
  title text not null,
  category text not null,
  price integer not null,
  condition text,
  location text,
  description text,
  status text default 'active',
  created_at timestamptz default now()
);
create table listing_images (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references listings(id) on delete cascade,
  image_url text not null,
  sort_order integer default 0
);
create table messages (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references listings(id),
  sender_id uuid references profiles(id),
  receiver_id uuid references profiles(id),
  body text not null,
  created_at timestamptz default now()
);
create table offers (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references listings(id),
  buyer_id uuid references profiles(id),
  amount integer not null,
  status text default 'pending',
  created_at timestamptz default now()
);
alter table profiles enable row level security;
alter table listings enable row level security;
alter table messages enable row level security;
alter table offers enable row level security;
create policy "Public listings are viewable" on listings for select using (status='active');
create policy "Users can manage own profile" on profiles for all using (auth.uid()=id);
create policy "Sellers manage own listings" on listings for all using (auth.uid()=seller_id);
