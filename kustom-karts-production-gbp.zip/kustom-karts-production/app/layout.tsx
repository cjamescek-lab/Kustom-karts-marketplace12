import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Kustom Karts Marketplace', description: 'Buy and sell karting parts and karts in the UK.' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
