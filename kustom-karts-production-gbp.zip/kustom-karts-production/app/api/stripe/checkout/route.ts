import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
export async function POST(req: NextRequest) {
  const stripeKey = process.env.STRIPE_SECRET_KEY;
  if (!stripeKey) return NextResponse.json({ error: 'Missing STRIPE_SECRET_KEY' }, { status: 500 });
  const stripe = new Stripe(stripeKey);
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [{ price_data: { currency: 'gbp' // GBP / Pounds Sterling, product_data: { name: 'Kustom Karts Marketplace Item' }, unit_amount: 1000 }, quantity: 1 }],
    success_url: `${siteUrl}/dashboard?success=true`,
    cancel_url: `${siteUrl}/listings?cancelled=true`
  });
  return NextResponse.redirect(session.url || siteUrl, { status: 303 });
}
