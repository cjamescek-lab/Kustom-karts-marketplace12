import Link from 'next/link';
import { formatGBP } from '@/lib/currency';
export default function ListingCard({item}: any){return <Link href={`/listings/${item.id}`} style={{textDecoration:'none',color:'inherit'}}><div className="card"><img src={item.image} alt={item.title}/><h3>{item.title}</h3><div className="price">{formatGBP(item.price)}</div><p>📍 {item.location}</p><small>{item.condition} · {item.category}</small></div></Link>}
