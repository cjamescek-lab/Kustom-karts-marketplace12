export const categories = ['Complete Karts','Chassis','Engines','Engine Parts','Wheels & Tyres','Racewear','Tools','Trailers','Wanted Ads'];
export const listings = [
  {id:'otk-tony-kart-racer-401r', title:'2023 OTK Tony Kart Racer 401R', price:2250, location:'Leicester, UK', category:'Complete Karts', image:'https://images.unsplash.com/photo-1558981852-426c6c22a060?q=80&w=1000&auto=format&fit=crop', seller:'Karting World', condition:'Used'},
  {id:'iame-x30-senior-engine', title:'IAME X30 Senior Engine', price:1150, location:'Birmingham, UK', category:'Engines', image:'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?q=80&w=1000&auto=format&fit=crop', seller:'Midlands Race Engines', condition:'Reconditioned'},
  {id:'vega-slick-tyre-set', title:'VEGA SLW Slick Tyre Set', price:180, location:'Leeds, UK', category:'Wheels & Tyres', image:'https://images.unsplash.com/photo-1578844251758-2f71da64c96f?q=80&w=1000&auto=format&fit=crop', seller:'Race Parts UK', condition:'New'},
  {id:'alfano-6-dash', title:'Alfano 6 Dashboard', price:295, location:'Manchester, UK', category:'Tools', image:'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1000&auto=format&fit=crop', seller:'Kart Tech', condition:'Used'},
  {id:'omp-ks3-race-suit', title:'OMP KS-3 Race Suit', price:299, location:'Bristol, UK', category:'Racewear', image:'https://images.unsplash.com/photo-1533561052604-c3beb6d55b8d?q=80&w=1000&auto=format&fit=crop', seller:'Racing Gear Store', condition:'New'}
];
