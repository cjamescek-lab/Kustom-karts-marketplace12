# Kustom Karts Marketplace — Production Starter

A deployable Next.js marketplace starter for buying and selling karts and karting parts.

## Included
- Homepage matching the approved red/black marketplace direction
- Listings page
- Listing detail page
- Sell item page
- Seller dashboard
- Messages mockup
- Admin dashboard
- Stripe checkout route placeholder
- Supabase database schema
- Vercel-ready config

## Launch steps
1. Create a free Vercel account.
2. Create a Supabase project.
3. Run `supabase/schema.sql` in Supabase SQL Editor.
4. Create a Stripe account and copy your API keys.
5. Copy `.env.example` to `.env.local` and fill in the values.
6. Run locally:
   ```bash
   npm install
   npm run dev
   ```
7. Deploy to Vercel.
8. In Vercel, add your domain `kustom-karts.co.uk` under Project → Settings → Domains.
9. Add your Vercel environment variables.
10. In Stripe, add your live keys and webhook later when real checkout/orders are enabled.

## Important
This is a production starter codebase, not a fully regulated payment/escrow platform. Before taking live payments, test Stripe thoroughly and add terms, privacy policy, refunds, seller verification and dispute handling.


## Currency

All listing prices are displayed in GBP using the £ symbol. Stripe Checkout is configured for `gbp` by default.
